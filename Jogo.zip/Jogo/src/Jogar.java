//CRIE UM JOGA QUE GERA UM NÚMERO ALEATORIO DE 0 A 100, O USUARIO TEM 5 CHANCES PARA ACERTAR, ORIENTADO A OBJETO COM MENU E J0PTION PANE

import java.util.Random;
import javax.swing.JOptionPane;


import java.util.Random;
import javax.swing.JOptionPane;

public class Jogar {
    public static void main(String[] args) {
        Random gerador = new Random();
        int numero = gerador.nextInt(100);
        int tentativas = 0;
        int chute = 0;
        int opcao = 0;
        String mensagem = "";
        String titulo = "JOGO DA ADIVINHAÇÃO";
        String texto = "Escolha uma opção";
        String[] opcoes = {"Jogar", "Sair"};

        while (opcao != 1) {
            opcao = JOptionPane.showOptionDialog(null, texto, titulo, 0, JOptionPane.QUESTION_MESSAGE, null, opcoes, opcoes[0]);
            if (opcao == 0) {
                // Resetar o número aleatório
                numero = gerador.nextInt(100);
                tentativas = 0;
                while (chute != numero && tentativas < 5) {
                    chute = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite um número de 0 a 100"));
                    if (chute > numero) {
                        mensagem = "O número é menor";
                    } else if (chute < numero) {
                        mensagem = "O número é maior";
                    } else {
                        mensagem = "Parabéns, você acertou!";
                    }
                    JOptionPane.showMessageDialog(null, mensagem);
                    tentativas++;
                }
                if (chute == numero) {
                    JOptionPane.showMessageDialog(null, "Você acertou em " + tentativas + " tentativas");
                } else {
                    JOptionPane.showMessageDialog(null, "Você perdeu, o número era " + numero);
                }
            }
        }
    }
}
